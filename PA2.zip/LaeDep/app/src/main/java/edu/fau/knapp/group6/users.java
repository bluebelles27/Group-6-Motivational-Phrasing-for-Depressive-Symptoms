package edu.fau.knapp.group6;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.Button;


public class users extends AppCompatActivity {
    // Declare our view variables

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.users);
        // Assign the views from the layout file to the corresponding variables

    }
}
